// JavaScript Document

$(document).ready(function(){
	
$(".calcLocationSub_sec li:nth-child(odd)").addClass("first");
$(".calcLocationSub_sec li:nth-child(even)").addClass("second");
$(".calcLocationHead_sec li:first").addClass("first");


$(".academicL_sec li:nth-child(odd)").addClass("lightBg");
$(".popularR_sec li:nth-child(even)").addClass("lightBg");

	$("#nextClick").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1").hide("fast");
		$(".surveyId2").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	$("#nextClick2").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2").hide("fast");
		$(".surveyId3").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	$("#nextClick3").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3").hide("fast");
		$(".surveyId4").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	$("#nextClick4").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4").hide("fast");
		$(".surveyId5").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	$("#nextClick5").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5").hide("fast");
		$(".surveyId6").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
		$("#nextClick6").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6").hide("fast");
		$(".surveyId7").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
		
		$("#nextClick7").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7").hide("fast");
		$(".surveyId8").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
		
		$("#nextClick8").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8").hide("fast");
		$(".surveyId9").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });	
		
		$("#nextClick9").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9").hide("fast");
		$(".surveyId10").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });	
		
		$("#nextClick10").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10").hide("fast");
		$(".surveyId11").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });	
		
		$("#nextClick11").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11").hide("fast");
		$(".surveyId12").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });	
		
		$("#nextClick12").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12").hide("fast");
		$(".surveyId13").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
		$("#nextClick13").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13").hide("fast");
		$(".surveyId14").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
		$("#nextClick14").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14").hide("fast");
		$(".surveyId15").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
		
		$("#nextClick15").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15").hide("fast");
		$(".surveyId16").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
		
		$("#nextClick16").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,surveyId16").hide("fast");
		$(".surveyId17").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
		
		$("#nextClick17").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,surveyId16,surveyId17").hide("fast");
		$(".surveyId18").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	$("#nextClick18").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,.surveyId15,.surveyId16,.surveyId17,.surveyId18").hide("fast");
		$(".surveyId19").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	$("#nextClick19").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19").hide("fast");
		$(".surveyId20").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	$("#nextClick20").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20").hide("fast");
		$(".surveyId21").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
		$("#nextClick21").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21").hide("fast");
		$(".surveyId22").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
		
		$("#nextClick22").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22").hide("fast");
		$(".surveyId23").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	$("#nextClick23").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23").hide("fast");
		$(".surveyId24").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	$("#nextClick24").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23,.surveyId24").hide("fast");
		$(".surveyId25").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
		$("#nextClick25").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23,.surveyId24,.surveyId25").hide("fast");
		$(".surveyId26").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
		
		$("#nextClick26").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23,.surveyId24,.surveyId25,.surveyId26").hide("fast");
		$(".surveyId27").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	
	$("#nextClick27").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23,.surveyId24,.surveyId25,.surveyId26,.surveyId27").hide("fast");
		$(".surveyId28").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
		$("#nextClick28").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23,.surveyId24,.surveyId25,.surveyId26,.surveyId27,.surveyId28").hide("fast");
		$(".surveyId29").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
		
			$("#nextClick29").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23,.surveyId24,.surveyId25,.surveyId26,.surveyId27,.surveyId28,.surveyId29").hide("fast");
		$(".surveyId30").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	$("#nextClick30").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23,.surveyId24,.surveyId25,.surveyId26,.surveyId27,.surveyId28,.surveyId29,.surveyId30").hide("fast");
		$(".surveyId31").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	$("#nextClick31").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23,.surveyId24,.surveyId25,.surveyId26,.surveyId27,.surveyId28,.surveyId29,.surveyId30,.surveyId31").hide("fast");
		$(".surveyId32").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	$("#nextClick32").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23,.surveyId24,.surveyId25,.surveyId26,.surveyId27,.surveyId28,.surveyId29,.surveyId30,.surveyId31,.surveyId32").hide("fast");
		$(".surveyId33").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
		$("#nextClick33").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23,.surveyId24,.surveyId25,.surveyId26,.surveyId27,.surveyId28,.surveyId29,.surveyId30,.surveyId31,.surveyId32,.surveyId33").hide("fast");
		$(".surveyId34").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
		
	$("#nextClick34").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".surveyId1,.surveyId2,.surveyId3,.surveyId4,.surveyId5,.surveyId6,.surveyId7,.surveyId8,.surveyId9,.surveyId10,.surveyId11,.surveyId12,.surveyId13,.surveyId14,surveyId15,.surveyId16,.surveyId17,.surveyId18,.surveyId19,.surveyId20,.surveyId21,.surveyId22,.surveyId23,.surveyId24,.surveyId25,.surveyId26,.surveyId27,.surveyId28,.surveyId29,.surveyId30,.surveyId31,.surveyId32,.surveyId33,.surveyId34").hide("fast");
		$(".surveyId34").show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	
	$(".submitDetails").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".calcSchemesShow").animate({left: '-350px', opacity:'0'},300).hide("fast");
		$(".goldLform4").animate({left: '0', height:'100%', opacity:'1'},500).show(500);
		  //$('.mobile-menu').toggleClass('active');
		return false;
    });
	
	$(".submitDetails2").click(function () {
        //$(".calcLoanSchemes_sec").slideToggle("slow")
		$(".submitDetailsShow2").animate({left: '-350px', opacity:'0'},300).hide("fast");
		$(".thankyouShow").animate({left: '0', height:'100%', opacity:'1'},500).show(500);
		$(".calculateSub_sec").addClass('minHeight');
		  //$('.mobile-1menu').toggleClass('active');
		return false;
    });

$(".showHover").hide();
$("#hover1").hover(function() {
    $("#show1").css({"display":"block"});
	//$('.projects li').addClass('active');
	}, function() {
    $("#show1").css({"display":"none"});
	//$('.projects li').removeClass('active');
});
$("#hover2").hover(function() {
    $("#show2").css({"display":"block"});
	}, function() {
    $("#show2").css({"display":"none"});
});
$("#hover3").hover(function() {
    $("#show3").css({"display":"block"});
	}, function() {
    $("#show3").css({"display":"none"});
});
$("#hover4").hover(function() {
    $("#show4").css({"display":"block"});
	}, function() {
    $("#show4").css({"display":"none"});
});
$("#hover5").hover(function() {
    $("#show5").css({"display":"block"});
	}, function() {
    $("#show5").css({"display":"none"});
});
$("#hover6").hover(function() {
    $("#show6").css({"display":"block"});
	}, function() {
    $("#show6").css({"display":"none"});
});
$("#hover7").hover(function() {
    $("#show7").css({"display":"block"});
	}, function() {
    $("#show7").css({"display":"none"});
});
$("#hover8").hover(function() {
    $("#show8").css({"display":"block"});
	}, function() {
    $("#show8").css({"display":"none"});
});
$("#hover9").hover(function() {
    $("#show9").css({"display":"block"});
	}, function() {
    $("#show9").css({"display":"none"});
});
$("#hover10").hover(function() {
    $("#show10").css({"display":"block"});
	}, function() {
    $("#show10").css({"display":"none"});
});
$("#hover11").hover(function() {
    $("#show11").css({"display":"block"});
	}, function() {
    $("#show11").css({"display":"none"});
});
$("#hover12").hover(function() {
    $("#show12").css({"display":"block"});
	}, function() {
    $("#show12").css({"display":"none"});
});
$("#hover13").hover(function() {
    $("#show13").css({"display":"block"});
	}, function() {
    $("#show13").css({"display":"none"});
});
$("#hover14").hover(function() {
    $("#show14").css({"display":"block"});
	}, function() {
    $("#show14").css({"display":"none"});
});

//$(".showHover").hide();
//$('.nextHover').hover(function(e) {
//    $(this).next('.showHover').show();
//});
	
$('.slider1').bxSlider({
     auto: true,
  });

 $('.sliderth1').bxSlider({
     auto: true,
	slideWidth: 195,
    minSlides: 2,
    maxSlides: 3,
	moveSlides: 3,
  });

//if ((screen.width<1023)) { 
//	
//	}
//	else if ((screen.width>=1024)) {
//	}
$('#fullpage').fullpage({
	sectionsColor: ['#ffffff', '#639561', '#E6EBEF', '#c8ccc5', '#26324A', '#A5C8C4', '#F2F2F2'],
	anchors: ['firstPage', 'secondPage', '3rdPage', '4thPage', '5thPage', '6thPage', '7thPage'],
	menu: '#menu',
	afterLoad: function(anchorLink, index){

		//section 2
		if(index == 2){
			//moving the image
			$('#section1').find('img').delay(500).animate({
				left: '0%'
			}, 1500, 'easeOutExpo');

			$('#section1').find('p').first().fadeIn(1800, function(){
				$('#section1').find('p').last().fadeIn(1800);
			});;

		}

		//section 3
		if(anchorLink == '3rdPage'){
			//moving the image
			$('#section2').find('.intro').delay(500).animate({
				left: '0%'
			}, 1500, 'easeOutExpo');
			
		}
	}
});

			
$(".fancybox").fancybox({
		'transitionIn'	:	'fade',
		'transitionOut'	:	'fade',
		'speedIn'		:	600, 
		'speedOut'		:	200, 
		'overlayShow'	:	false,
		'showCloseButton'	: false,
});

$(".mobile-menu").click(function () {
        $(".mobile-show").slideToggle("slow")
		$(".langNav").slideUp(300)
		  $('.mobile-menu').toggleClass('active');
		return false;
    });

$(".loginShow").hide();
jQuery('.login').click(function(){
	if (!jQuery(".loginShow").is(":visible"))
		jQuery('.login').addClass("active");
		jQuery(".loginShow").slideToggle('slow', function() {
	if (!jQuery(".loginShow").is(":visible"))
		jQuery('.login').removeClass("active");
	});
	});

});




